A YouTube video picker for Umbraco.

Many Thanks to Jeavon for the Property Value Convertor from the basic JSON we save to the more useful & strongly typed Video object, along with the PackageAction to add the assembly binding to the Web.Config